To run the Moquette distribution, untar the archive and run the script bin/moquette.sh
